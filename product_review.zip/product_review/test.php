<?php

$localIP = getHostByName(getHostName());

// Displaying the address  
echo $localIP;
