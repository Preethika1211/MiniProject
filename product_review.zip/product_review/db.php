<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "productReview";

// Create connection
$connection = new mysqli($servername, $username, $password, $dbname);
